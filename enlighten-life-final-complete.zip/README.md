# Enlighten Life

이 파일들은 잡지형 블로그 시스템입니다.

## 글 수정 위치
글은 `posts.js` 하나만 수정하면 됩니다.

- title: 글 제목
- category: 카테고리
- date: 날짜
- excerpt: 카드에 보이는 짧은 소개
- body: 본문
