function nav(){
  return `
  <nav class="nav">
    <a href="index.html">최신 글</a>
    <a href="meditation.html">명상</a>
    <a href="coffee.html">커피</a>
    <a href="parents.html">부모님</a>
    <a href="journey.html">생의 여행</a>
    <a href="language.html">시와 언어</a>
    <a href="about.html">About</a>
  </nav>`;
}

function footer(){
  return `<footer>Enlighten Life · 삶 전체가 명상이 되는 길</footer>`;
}

function card(post){
  return `
  <article class="post-card">
    <a href="article.html?id=${post.id}">
      <div class="meta">${post.date} · ${post.category}</div>
      <h2>${post.title}</h2>
      <p>${post.excerpt}</p>
      <div class="read">계속 읽기 →</div>
    </a>
  </article>`;
}

function renderHome(){
  document.body.insertAdjacentHTML("afterbegin", `
    <header class="header">
      <h1>Enlighten<br>Life</h1>
      <p>삶 전체가 명상이 되는 길. 명상, 커피, 부모님, 생의 여행과 시와 언어의 기록.</p>
    </header>
    ${nav()}
  `);

  const latest = posts.slice(0,8);
  document.querySelector("main").innerHTML = `
    <div class="label">Latest Essays</div>
    <section class="grid">
      ${latest.map(card).join("")}
    </section>
  `;
  document.body.insertAdjacentHTML("beforeend", footer());
}

function renderCategory(category,title,desc){
  document.body.insertAdjacentHTML("afterbegin", nav());
  const list = posts.filter(p=>p.category===category);
  document.querySelector("main").innerHTML = `
    <section class="category-head">
      <h1>${title}</h1>
      <p>${desc}</p>
    </section>
    <section class="grid">
      ${list.map(card).join("")}
    </section>
  `;
  document.body.insertAdjacentHTML("beforeend", footer());
}

function renderArticle(){
  document.body.insertAdjacentHTML("afterbegin", nav());
  const id = new URLSearchParams(location.search).get("id");
  const post = posts.find(p=>p.id===id) || posts[0];
  const i = posts.indexOf(post);
  const prev = posts[i-1];
  const next = posts[i+1];

  document.querySelector("main").innerHTML = `
    <article class="article">
      <div class="meta">${post.date} · ${post.category}</div>
      <h1>${post.title}</h1>
      <p class="lead">${post.excerpt}</p>
      <div class="body">${post.body}</div>
      <div class="article-nav">
        <span>${prev ? `<a href="article.html?id=${prev.id}">← 이전 글</a>` : ""}</span>
        <span>${next ? `<a href="article.html?id=${next.id}">다음 글 →</a>` : ""}</span>
      </div>
    </article>
  `;
  document.body.insertAdjacentHTML("beforeend", footer());
}
