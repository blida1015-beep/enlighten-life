const posts = [
  {id:"meditation-01", category:"명상", date:"2026.06.20", title:"명상이란 무엇인가", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"meditation-02", category:"명상", date:"2026.06.20", title:"왜 시작점으로 돌아가야 하는가", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"meditation-03", category:"명상", date:"2026.06.20", title:"세상은 어떤 곳인가", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"meditation-04", category:"명상", date:"2026.06.20", title:"사랑의 언어", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"meditation-05", category:"명상", date:"2026.06.20", title:"통과의 기록", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},

  {id:"coffee-01", category:"커피", date:"2026.06.20", title:"커피가 내 삶에 들어오던 날", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"coffee-02", category:"커피", date:"2026.06.20", title:"스승을 만나다", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"coffee-03", category:"커피", date:"2026.06.20", title:"불과 향기 안에서 배운 것들", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"coffee-04", category:"커피", date:"2026.06.20", title:"갓볶은 커피의 향기", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"coffee-05", category:"커피", date:"2026.06.20", title:"담미, 삶의 맛과 향을 담아서", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},

  {id:"parents-01", category:"부모님", date:"2026.06.20", title:"내가 처음으로 선택한 두 사람", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"parents-02", category:"부모님", date:"2026.06.20", title:"평범한 일상 속 사랑", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"parents-03", category:"부모님", date:"2026.06.20", title:"아버지라는 존재", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"parents-04", category:"부모님", date:"2026.06.20", title:"어머니라는 존재", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"parents-05", category:"부모님", date:"2026.06.20", title:"생의 빛", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},

  {id:"journey-01", category:"생의 여행", date:"2026.06.20", title:"시작도 끝도 없는 시간 속에서", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"journey-02", category:"생의 여행", date:"2026.06.20", title:"이상한 아이", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"journey-03", category:"생의 여행", date:"2026.06.20", title:"인고의 시간, 기다림", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"journey-04", category:"생의 여행", date:"2026.06.20", title:"칼춤을 추다", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"journey-05", category:"생의 여행", date:"2026.06.20", title:"첫 번째 안내자", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"journey-06", category:"생의 여행", date:"2026.06.20", title:"보석 같은 기억들", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},

  {id:"language-01", category:"시와 언어", date:"2026.06.20", title:"시", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"language-02", category:"시와 언어", date:"2026.06.20", title:"짧은 산문", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"language-03", category:"시와 언어", date:"2026.06.20", title:"명상 노트", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"language-04", category:"시와 언어", date:"2026.06.20", title:"꿈의 기록", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."},
  {id:"language-05", category:"시와 언어", date:"2026.06.20", title:"순간의 통찰", excerpt:"여기에 짧은 소개문을 씁니다.", body:"여기에 본문을 씁니다."}
];
