function renderCards(filter="전체"){
  const wrap = document.querySelector("#post-list");
  if(!wrap) return;
  const list = filter==="전체" ? posts : posts.filter(p=>p.category===filter);
  wrap.innerHTML = list.map(p => `
    <article class="post-card">
      <div class="meta">${p.date} · ${p.category}</div>
      <h2>${p.title}</h2>
      <p>${p.excerpt}</p>
      <a href="article.html?id=${p.id}">계속 읽기 →</a>
    </article>
  `).join("");
}

function renderArticle(){
  const area = document.querySelector("#article");
  if(!area) return;
  const id = new URLSearchParams(location.search).get("id");
  const post = posts.find(p=>p.id===id) || posts[0];
  area.innerHTML = `
    <div class="meta">${post.date} · ${post.category}</div>
    <h1>${post.title}</h1>
    <p class="lead">${post.excerpt}</p>
    <div class="body">${post.body.replaceAll("\n","<br>")}</div>
    <p><a href="index.html">← 목록으로</a></p>
  `;
}

document.addEventListener("DOMContentLoaded", ()=>{
  renderCards();
  renderArticle();

  document.querySelectorAll("[data-filter]").forEach(btn=>{
    btn.addEventListener("click", e=>{
      e.preventDefault();
      renderCards(btn.dataset.filter);
    });
  });
});
